%RESEARCH_KSLYAPS   Parallelised code to compute Lyap expts for KS PDE.
%   RESEARCH_KSLYAPS is a script (to be run in parallel on maths1) that
%   computes spectra of Lyapunov exponents for the Kuramoto-Sivashinsky
%   PDE for domain sizes L=0.1:0.1:100, and saves the results as ASCII
%   text that can be read in for a Lyapunov exponent diagram plot.

% Code author: Russell Edson
% Date last modified: 15/01/2018

   % Number of parallel processes to run
%   cores = 7;
  cores = 20;
   
   % Current time for the timestamp
   currenttime = timestamp
   
   % Set parameters for the Lyapunov spectrum algorithm
   % (simulate to t=2000, reorth time=2, 1000 iterations, eps=1e-6,
   % 24 Lyap expts. suffices to compute DKY for L=100)
   t0 = 0;
   m = 24;
   tau = 2000;
   tt = 2;
   nn = 1000;
   eps = 1e-6;
   odesolver = @(dudt, t, u0) ode15s(dudt, t, u0, ...
     odeset('abstol', 1e-9, 'reltol', 1e-9));
   
   % Solving for a range of LLs
%   LLs = [12 13.5 22 36 60 96 100];
  LLs = 0.1:0.1:100;
 
   % Set up the simulator (periodic)
   simulator = 'ksperiodicspectral';
   dudt_func = @dudt_ksperiodic_spectral;
   kmax = 9;

   % Set up the simulator (odd-periodic)
%    simulator = 'ksoddperiodicfinitediff';
%    dudt_func = @dudt_ksoddperiodic_finitediff;
%    kmax = 9;
   
   % Define a thread-safe save closure
   intermediatesavelyaps = @(dir, LLstr, lyaps) save([dir, '/L', LLstr, ...
     '_lyaps.txt'], 'lyaps', '-ascii');
   intermediatesavestd = @(dir, LLstr, std) save([dir, '/L', LLstr, ...
     '_stddev.txt'], 'std', '-ascii');
   intermediatesaveseq = @(dir, LLstr, seq) save([dir, '/L', LLstr, ...
     '_seq.txt'], 'seq', '-ascii');
   intermediatesavetee = @(dir, LLstr, tee) save([dir, '/L', LLstr, ...
     '_tee.txt'], 'tee', '-ascii');
 
   % Directory for results
   directory = ['lyaps_' simulator '_' currenttime];
   mkdir(directory);
   
   lyaps_LLs = nan(m, length(LLs));
   parpool(cores);
   parfor(LL_idx = 1:length(LLs), cores)
   %for LL_idx = 1:length(LLs)
     % Set up the Kuramoto-Sivashinsky simulation (periodic)
     % (Need at least m points for m Lyap expts!)
     LL = LLs(LL_idx);
     n = floor(LL*kmax/pi);
     n = n + mod(n, 2);
     n = max(n, m);
     n = n + mod(n, 2);   % Really need this even for spectral scheme
     dudt = @(t, u) dudt_func(t, u, n, LL);
     u0 = randn(n, 1);
     
     % Set up the Kuramoto-Sivashinsky simulation (odd-periodic)
     % (Need at least m interior points for m Lyap expts!)
%      LL = LLs(LL_idx);
%      n = floor(LL*kmax/pi);
%      n = n + mod(n, 2);
%      n = max(n, m);
%      n = n + mod(n, 2);   % Match with the spectral scheme # of points
%      
%      % For finite difference, need to account for two boundary points
%      dudt = @(t, u) dudt_func(t, u, n+2, LL);
%      u0 = randn(n, 1);
       
     [lyaps, std, seq, ~, tee] = lyapunovexpts(dudt, u0, t0, m, tau, tt, ...
       nn, eps, odesolver);
     lyaps_LLs(:,LL_idx) = lyaps;
       
     % Save results in a thread-safe way
     thisLL = num2str(LL, '%05.1f');
     thisLL(thisLL == '.') = 'p';
     intermediatesavelyaps(directory, thisLL, lyaps);
     intermediatesavestd(directory, thisLL, std);
     intermediatesaveseq(directory, thisLL, seq);
     intermediatesavetee(directory, thisLL, tee);
       
     % Print a message to the log check that everything is okay
     % (This doesn't need to be thread-safe.)
     fprintf(['done L=' thisLL '\n']);
   end
   
   % Save full results (fail-safe.)
   save([mfilename '_' simulator '_' currenttime '.txt'], ...
     'lyaps_LLs', '-ascii');