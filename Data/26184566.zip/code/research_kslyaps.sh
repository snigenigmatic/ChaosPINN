#!/bin/bash

#RESEARCH_KSLYAPS.SH
#   Runs the parallelised MATLAB code to find the Lyapunov exponents of the
#   Kuramoto-Sivashinsky PDE in a headless session. Logs the MATLAB output
#   to matlab_out.log.

# Code author: Russell Edson
# Date last modified: 19/11/2017

renice 10 -p $$
matlab -nodisplay -logfile "matlab_out.log" -r "warning on all; warning on backtrace; warning on verbose; research_kslyaps; quit" < /dev/null