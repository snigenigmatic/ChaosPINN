function dudt = dudt_ksoddperiodic_finitediff(t, u, n, LL)
%DUDT_KSODDPERIODIC_FINITEDIFF   K-S PDE, odd-periodic BCs, finite diff scheme.
%   DUDT = DUDT_KSODDPERIODIC_FINITEDIFF(T, U, N, LL) evaluates the
%   Kuramoto-Sivashinsky PDE (discretised as an ODE system)
%      du/dt + d4u/dx4 + d2u/dx2 + u*du/dx = 0,
%   on the spatial domain 0<x<LL with 'odd-periodic' boundary conditions u=0 
%   and d2u/dx2=0 on x=0,LL, at the given time T and state U=[u1 u2 ... uN]'.
%   The PDE is discretised by an N-point finite difference scheme (with
%   error O(dx^2)). Use with the standard MATLAB ODE solvers.
%
%   *This code has been written such that multiple initial conditions may
%   be computed simultaneously with the MATLAB ODE solvers by passing in
%   multiple initial conditions as columns of a matrix. The code usage
%   example elucidates the simultaneous solving.
%
%   Example
%         LL = 50;
%         n = 80;
%         x = linspace(0, LL, n)';
%         x = x(2:end-1);
%         t = (0:10:50);
%         dudt = @(t, u) dudt_ksoddperiodic_finitediff(t, u, n, LL);
%         u0_1 = sin(pi*x/LL);
%         u0_2 = u0_1 + 1e-2*randn(size(u0_1));
%         [t, u] = ode15s(dudt, t, [u0_1 u0_2]);
%         u_1 = u(:,1:end/2);
%         u_2 = u(:,end/2+1:end);
%         figure, mesh(x, t, u_1, 'EdgeColor', 'r', 'FaceColor', 'none', ...
%           'MeshStyle', 'row');
%         hold on, mesh(x, t, u_2, 'EdgeColor', 'b', 'FaceColor', 'none', ...
%           'MeshStyle', 'row');
%      simulates the Kuramoto-Sivashinsky PDE on the hyperchaotic domain
%      [0,50] with an 80-point finite difference scheme, for an initial
%      half-sinusoid sin(pi*x/LL) and an O(1e-2) perturbation, and plots
%      overlapping solutions to show the chaos.

% Code author: Russell Edson
% Date last modified: 03/11/2017

  % Boundary conditions: u=d2u/dx2=0 on the boundary x=0,LL
  uleft = @(t) zeros(size(t));
  uright = @(t) zeros(size(t));
  d2udx2left = @(t) zeros(size(t));
  d2udx2right = @(t) zeros(size(t));

  u = reshape(u, n-2, []);
  cols = size(u, 2);
  u = [repmat(uleft(t), 1, cols); u; repmat(uright(t), 1, cols)];
  
  dx = LL/(n-1);
  j = 2:(n-1);
  
  % Error O(dx^2) finite difference for the time derivative
  up1 = u(j+1,:);
  um1 = u(j-1,:);
  dudx = (up1 - um1)/(2*dx);
  d2udx2 = (up1 - 2*u(j,:) + um1)/dx^2;
  d2udx2 = [repmat(d2udx2left(t), 1, cols); d2udx2; ...
    repmat(d2udx2right(t), 1, cols)];

  d2udx2p1 = d2udx2(j+1,:);
  d2udx2m1 = d2udx2(j-1,:);
  d4udx4 = (d2udx2p1 - 2*d2udx2(j,:) + d2udx2m1)/dx^2;
    
  dudt = -d4udx4 - d2udx2(j,:) - u(j,:).*dudx;
  dudt = reshape(dudt, [], 1);
end