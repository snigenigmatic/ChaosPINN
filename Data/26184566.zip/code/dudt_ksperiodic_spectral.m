function dudt = dudt_ksperiodic_spectral(t, u, n, LL)
%DUDT_KSPERIODIC_SPECTRAL   K-S PDE, periodic BCs, spectral scheme.
%   DUDT = DUDT_KSPERIODIC_SPECTRAL(T, U, N, LL) evaluates the
%   Kuramoto-Sivashinsky PDE (discretised as an ODE system)
%      du/dt + d4u/dx4 + d2u/dx2 + u*du/dx = 0,
%   with periodic boundary conditions on the spatial domain 0<x<LL, at
%   the given time T and state U=[u1 u2 ... uN]'. The PDE is discretised
%   by an N-point Fourier spectral scheme. Use with the standard MATLAB 
%   ODE solvers.
%
%   *This code has been written such that multiple solutions may be
%   computed simultaneously with the MATLAB ODE solvers by passing in
%   multiple initial conditions as columns of a matrix. The code usage
%   example elucidates the simultaneous solving.
%
%   Example
%         LL = 50;
%         n = 64;
%         x = (LL/n)*(0:n-1)';
%         t = (0:10:50);
%         dudt = @(t, u) dudt_ksperiodic_spectral(t, u, n, LL);
%         u0_1 = sin(2*pi*x/LL);
%         u0_2 = u0_1 + 1e-2*randn(size(u0_1));
%         [t, u] = ode15s(dudt, t, [u0_1 u0_2]);
%         u_1 = u(:,1:end/2);
%         u_2 = u(:,end/2+1:end);
%         figure, mesh(x, t, u_1, 'EdgeColor', 'r', 'FaceColor', 'none', ...
%           'MeshStyle', 'row');
%         hold on, mesh(x, t, u_2, 'EdgeColor', 'b', 'FaceColor', 'none', ...
%           'MeshStyle', 'row');
%      simulates the Kuramoto-Sivashinsky PDE on the hyperchaotic domain
%      [0,50] with a 64-point spectral scheme, for an initial sinusoid
%      sin(2*pi*x/LL) and an O(1e-2) perturbation, and plots overlapping
%      solutions to show the chaos.

% Code author: Russell Edson
% Date last modified: 24/10/2017

  u = reshape(u, n, []);
  cols = size(u, 2);
  
  % Zero the nn/2 wavenumber for the first derivative
  ik = 1i*(repmat((2*pi/LL)*[0:n/2-1 0 -n/2+1:-1]', 1, cols));
  k2 = repmat((2*pi/LL)*[0:n/2 -n/2+1:-1]', 1, cols).^2;
  k4 = k2.^2;
  
  dudt = ifft((k2 - k4).*fft(u)) - u.*ifft(ik.*fft(u));
  dudt = reshape(dudt, [], 1);
end
